# Hexada Developer Sandbox
Full-stack Web3 + ML + AI + Solidity dev sandbox